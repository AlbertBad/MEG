﻿//Trae comentarios y algunos ejemplos que ya no se implementaron al tratar de descubrir como obtener los datos de los asp

$(document).ready(function () {
    //Deshabilita el boton al cargar la pagina
    $("input[id$='btnRegistrar']").prop("disabled", true);
    $("input[id$='btnSignup2']").prop("disabled", true);

    //Copia string de input a otros input o asp:textbox
    /*
    $("#ipUsername").keyup(function () {
        var copytext = $("#ipUsername").val();
        copy();
        $("input[id$='txtUsername']").val(copytext);
        checkForm();
    });
    */

    //Copia string de asp:textbox a un input    
    $("input[id$='txtUsername']").change(function () {
        //var values = $("input[id$='txtUsername']").val();
        //$("#ipUsername").val(values);
        checkForm();
    });

    $("input[id$='txtEmail']").change(function () {
        checkForm();
    });

    $("input[id$='txtPassword']").change(function () {
        checkForm();
    });

    $("input[id$='txtConfirmPassword']").change(function () {
        checkForm();
    });

    $("[id*=ddlEmpresa]").change(function () {
        checkForm();
    });

    $("input[id$='btnRegistrar']").click(function () {
        checkForm(); //Tiene algo de redundancia revisar despues de que se supone que revisa cada change() y se activa SOLO al estar bien todo pero bueno!!!!!
        //$('#signup')[0].reset(); //Reinicia el formulario NO RECOMENDADO
        alert("Control del formulario de registro de usuario funciona Correctamente |(");
    });

    $("input[id$='btnLimpiar']").click(function () {
        checkClear();
    });
    //Empieza script para signup2
    $("input[id$='txtCorporationname']").change(function () {
        checkSignup();
    });

    $("input[id$='txtPostal']").change(function () {
        checkSignup();
    });

    $("input[id$='txtTelephone']").change(function () {
        checkSignup();
    });

    $("input[id$='txtCorreo']").change(function () {
        checkSignup();
    });

    $("input[id$='btnSignup2']").click(function () {
        checkSignup();
        window.location.href = 'Signup.aspx';
        alert(" OK");
    });

    $("input[id$='btnLimpiar2']").click(function () {
        checkClear();
        //var frmMain = document.forms[0];
        //frmMain.reset();
        //$('#signup2')[0].reset(); //Reinicia el formulario NO ME GUSTO podria mejorar
    });
    //regresa el texto y valor de lista selecionado en el listitem
    /*
    function returnEmpresa() {
            var ddlEmpresa = $("[id*=ddlEmpresa]");
            var selectedText = ddlEmpresa.find("option:selected").text();
            var selectedValue = ddlEmpresa.val();
            alert("Selected Text: " + selectedText + " Value: " + selectedValue);
    }
    */
    //Funcion para habilitar boton
    function checkForm() {
        //Longitud del string en input
        var longUser = $("input[id$='txtUsername']").val().length;
        var longEmail = $("input[id$='txtEmail']").val().length;
        var longPass = $("input[id$='txtPassword']").val().length;
        var longConf = $("input[id$='txtConfirmPassword']").val().length;
        //Obtiene los valores de dropdownlist ddlEmpresa
        var ddlEmpresa = $("[id*=ddlEmpresa]");
        var selectedText = ddlEmpresa.find("option:selected").text();
        var selectedValue = ddlEmpresa.val();
        //Obtiene texto de password y confirmacion
        var veriPass = $("input[id$='txtPassword']").val();
        var confPass = $("input[id$='txtConfirmPassword']").val();
        //Verificar Longitud del textbox y habilita boton
        if (longUser > 3 && longEmail > 6 && longPass > 6 && longConf > 6 && longPass === longConf && selectedValue > 1 && veriPass === confPass) {
            $("input[id$='btnRegistrar']").prop("disabled", false);
        } else {
            $("input[id$='btnRegistrar']").prop("disabled", true);
        }
    }

    function checkSignup() {
        //Longitud del string en input
        var longCorp = $("input[id$='txtCorporationname']").val().length;
        var longPost = $("input[id$='txtPostal']").val().length;
        var longTele = $("input[id$='txtTelephone']").val().length;
        var longEmail = $("input[id$='txtCorreo']").val().length;        
        //Verificar Longitud del textbox y habilita boton
        if (longCorp > 3 && longPost > 5 && longTele > 7 && longEmail > 6) {
            $("input[id$='btnSignup2']").prop("disabled", false);
        } else {
            $("input[id$='btnSignup2']").prop("disabled", true);
        }
    }

    function checkClear() {
        $("input[id$='txtUsername']").val("");
        $("input[id$='txtEmail']").val("");
        $("input[id$='txtPassword']").val("");
        $("input[id$='txtConfirmPassword']").val("");
        $("input[id$='txtCorporationname']").val("");
        $("input[id$='txtPostal']").val("");
        $("input[id$='txtTelephone']").val("");
        $("input[id$='txtCorreo']").val(""); 
    }


});

//funcion para pasar de input a otro
/*
function copy() {
    document.getElementById("ipPrueba").value = document.getElementById("ipUsername").value;
}
*/







