﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using UTP_Ducks.Controlador;

namespace UTP_MEG.MODELO
{
    public class Clases
    {
    }
    public class Empresa
    {
        public String NombreEmpresa { set; get; }
        public String DireccionEmpresa { set; get; }
        public int Telefono { set; get; }
        public String EmailEmpresa { set; get; }

        public Empresa()
        {
            NombreEmpresa = "";
            DireccionEmpresa = "";
            Telefono = 00000000;
            EmailEmpresa = "";
        }
        public Empresa(string ne, string de, int t, string ee)
        {
            NombreEmpresa = ne;
            DireccionEmpresa = de;
            Telefono = t;
            EmailEmpresa = ee;
        }

        //Metodo alta de datos para la empresa
        public int altaEmpresa()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "execute altaEmpresa '"+NombreEmpresa+"','"+DireccionEmpresa+"',"+Telefono+",'"+EmailEmpresa+"'";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        //Metodo para eliminar una empresa
        public int Eliminar(string nom)
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Delete from Empresa where NombreEmpresa='"+nom+"'";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        //Metodo para cargar datos en una lista
        public int carga(DropDownList ddl)
        {
            Conexion selecciona = new Conexion();
            SqlDataReader lector;
            if (selecciona.conectar())
            {
                selecciona.construye_reader("SELECT NombreEmpresa FROM Empresa");
                lector = selecciona.ejecuta_reader();
                while (lector.Read())
                    ddl.Items.Add(lector.GetString(0).ToString());
                selecciona.desconectar();
                selecciona.dr.Close();
                return 1;
            }
            else return -1;
        }
        //Metodo para hacer una modificacion
        public int ModificarEmpresa(string d,string t,string n)
        {
            SqlCommand Comando;
            Conexion actualiza = new Conexion();
            int regresa = 0;
            if (actualiza.conectar())
            {
                Comando = actualiza.construye_command("update Empresa set DireccionEmpresa='"+d+"', Telefono="+t+" where NombreEmpresa='"+n+"'");
                if (actualiza.ejecutanonquery() != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                actualiza.desconectar();
            }
            else
                return -1;
            return regresa;
        }
        //Metodo para regresar el id
        public int regresaID(string nem)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            string m = "";
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select idEmpresa from Empresa where NombreEmpresa='"+nem+"'");
                    fila = selecciona.extrae_registro(adaptador, "Empresa");
                    return Convert.ToInt32(fila["idEmpresa"]);
                }
                catch (Exception)
                {
                    m = "No se encuentra la Empresa ";
                    return 0;
                }
            }
            else
                return -1;
        }
        //Metodo para hacer consultas y mostrarlas en un gridview
        public void Consulta(GridView gv,string nom)
        {

            Conexion consulta = new Conexion();
            SqlDataReader lector;
            if (consulta.conectar())
            {
                consulta.construye_reader("execute BuscaEmpresa '"+nom+"'");
                lector = consulta.ejecuta_reader();
                gv.DataSource = lector;
                gv.DataBind();
                consulta.dr.Close();
                consulta.desconectar();
            }
        }
    }
    public class Usuario
    {
        public int idEmpresa { set; get; }
        public String NombreUsuario { set; get; }
        public String Password_2 { set; get; }
        public String Email { set; get; }
        public String Verificacion { set; get; }
        public DateTime FechaDLogeo { set; get; }
        public DateTime UltimaConexion { set; get; }

        public Usuario()
        {
            idEmpresa = 0;
            NombreUsuario = "";
            Password_2 = "";
            Email = "";
            Verificacion = "";
            FechaDLogeo = DateTime.Now;
            UltimaConexion = DateTime.Now;

        }
        public Usuario(int id,string nu,string p,string e,string v,DateTime f,DateTime u)
        {
            idEmpresa = id;
            NombreUsuario =nu;
            Password_2 = p;
            Email = e;
            Verificacion = v;
            FechaDLogeo =f;
            UltimaConexion = u;
        }

        //Metodo alta de datos para el usuario
        public int altaUsuario()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "execute altaUsuario "+idEmpresa+",'"+NombreUsuario+"','"+Password_2+"','"+Email+"','"+Verificacion+"','"+FechaDLogeo.ToShortDateString()+"','"+UltimaConexion.ToShortDateString()+"'";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        //Metodo para cargar datos en una lista
        public int carga(DropDownList ddl)
        {
            Conexion selecciona = new Conexion();
            SqlDataReader lector;
            if (selecciona.conectar())
            {
                selecciona.construye_reader("SELECT NomUsuario FROM Usuario");
                lector = selecciona.ejecuta_reader();
                while (lector.Read())
                    ddl.Items.Add(lector.GetString(0).ToString());
                selecciona.desconectar();
                selecciona.dr.Close();
                return 1;
            }
            else return -1;
        }
        //Metodo para regresar el id
        public int regresaIDU()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            string m = "";
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("SELECT TOP 1 (idUsuario) FROM Usuario Order By (idUsuario) desc");
                    fila = selecciona.extrae_registro(adaptador, "Usuario");
                    return Convert.ToInt32(fila["idUsuario"]);
                }
                catch (Exception)
                {
                    m = "No se encuentra al Usuario ";
                    return 0;
                }
            }
            else
                return -1;
        }
    }
    public class RequisitosCriticos
    {
        public int idUsuario { set; get; }
        public int NumRequisito { set; get; }
        public String DireccionRequisito { set; get; }
        public String Verificacion { set; get; }

        public RequisitosCriticos()
        {
            idUsuario = 0;
            NumRequisito = 0;
            DireccionRequisito = "";
            Verificacion = "";
        }
        public RequisitosCriticos(int i,int num,string d,string v)
        {
            idUsuario = i;
            NumRequisito = num;
            DireccionRequisito = d;
            Verificacion = v;
        }
        public int altaRequisitosC()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "execute altaRequisitoC "+idUsuario+","+NumRequisito+",'"+DireccionRequisito+"','"+Verificacion+"'";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        //Metodos para mostrar los archivos para su visualizacion
        public String regresaNom1(string nem)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            string m = "";
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select TOP 1 (DireccionRequisito) from RequisitosCriticos r inner join Usuario u on r.idUsuario=u.idUsuario"+ 
                        "where NomUsuario = '"+nem+"' order by(DireccionRequisito) asc");
                    fila = selecciona.extrae_registro(adaptador, "RequisitosCriticos");
                    return fila["DireccionRequisito"].ToString();
                }
                catch (Exception)
                {
                    m = "No se encuentra el Requisito";
                    return m;
                }
            }
            else
            {
                m = "Fallo en la base de datos";
                return m;

            }
        }
        public String regresaNom2(string nem)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            string m = "";
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select TOP 2 (DireccionRequisito) from RequisitosCriticos r inner join Usuario u on r.idUsuario=u.idUsuario" +
                        "where NomUsuario = '" + nem + "' order by(DireccionRequisito) asc");
                    fila = selecciona.extrae_registro(adaptador, "RequisitosCriticos");
                    return fila["DireccionRequisito"].ToString();
                }
                catch (Exception)
                {
                    m = "No se encuentra el Requisito";
                    return m;
                }
            }
            else
            {
                m = "Fallo en la base de datos";
                return m;

            }
        }
        public String regresaNom3(string nem)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            string m = "";
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select TOP 3 (DireccionRequisito) from RequisitosCriticos r inner join Usuario u on r.idUsuario=u.idUsuario" +
                        "where NomUsuario = '" + nem + "' order by(DireccionRequisito) asc");
                    fila = selecciona.extrae_registro(adaptador, "RequisitosCriticos");
                    return fila["DireccionRequisito"].ToString();
                }
                catch (Exception)
                {
                    m = "No se encuentra el Requisito";
                    return m;
                }
            }
            else
            {
                m = "Fallo en la base de datos";
                return m;

            }
        }
        public String regresaNom4(string nem)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            string m = "";
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select TOP 1 (DireccionRequisito) from RequisitosCriticos r inner join Usuario u on r.idUsuario=u.idUsuario" +
                        "where NomUsuario = '" + nem + "' order by(DireccionRequisito) asc");
                    fila = selecciona.extrae_registro(adaptador,"RequisitosCriticos");
                    return fila["DireccionRequisito"].ToString();
                }
                catch (Exception)
                {
                    m = "No se encuentra el Requisito";
                    return m;
                }
            }
            else
            {
                m = "Fallo en la base de datos";
                return m;

            }
        }
    }
    public class RequisitosNoCriticos
    {
        public int idUsuario { set; get; }
        public String NombreRequisito { set; get; }
        public int NumRequisito { set; get; }
        public String VerificacionRNC { set; get; }

        public RequisitosNoCriticos()
        {
            idUsuario = 0;
            NombreRequisito = "";
            NumRequisito = 0;
            VerificacionRNC = "";
        }
        public RequisitosNoCriticos(int i,string nr,int num,string v)
        {
            idUsuario = i;
            NombreRequisito = nr;
            NumRequisito = num;
            VerificacionRNC = v;
        }
        public int altaRequisitosNC()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "execute altaRequisitoNC "+idUsuario+",'"+NombreRequisito+"',"+NumRequisito+",'"+VerificacionRNC+"'";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        //Metodos para mostrar los archivos para su visualizacion
        public String regresaNom1(string nem)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            string m = "";
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select TOP 1 (NombreRequisito) from RequisitosNoCriticos r inner join Usuario u on r.idUsuario=u.idUsuario"+
                        " where NomUsuario = '"+nem+"' order by(NombreRequisito) asc");
                    fila = selecciona.extrae_registro(adaptador,"RequisitosNoCriticos");
                    return fila["NombreRequisito"].ToString();
                }
                catch (Exception)
                {
                    m = "No se encuentra el Requisito";
                    return m;
                }
            }
            else
            {
                m = "Fallo en la base de datos";
                return m;

            }
        }
        public String regresaNom2(string nem)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            string m = "";
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select TOP 2 (NombreRequisito) from RequisitosNoCriticos r inner join Usuario u on r.idUsuario=u.idUsuario" +
                        " where NomUsuario = '" + nem + "' order by(NombreRequisito) asc");
                    fila = selecciona.extrae_registro(adaptador, "RequisitosNoCriticos");
                    return fila["NombreRequisito"].ToString();
                }
                catch (Exception)
                {
                    m = "No se encuentra el Requisito";
                    return m;
                }
            }
            else
            {
                m = "Fallo en la base de datos";
                return m;

            }
        }
        public String regresaNom3(string nem)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            string m = "";
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select TOP 3 (NombreRequisito) from RequisitosNoCriticos r inner join Usuario u on r.idUsuario=u.idUsuario" +
                        " where NomUsuario = '" + nem + "' order by(NombreRequisito) asc");
                    fila = selecciona.extrae_registro(adaptador, "RequisitosNoCriticos");
                    return fila["NombreRequisito"].ToString();
                }
                catch (Exception)
                {
                    m = "No se encuentra el Requisito";
                    return m;
                }
            }
            else
            {
                m = "Fallo en la base de datos";
                return m;

            }
        }
        public String regresaNom4(string nem)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            string m = "";
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select TOP 4 (NombreRequisito) from RequisitosNoCriticos r inner join Usuario u on r.idUsuario=u.idUsuario" +
                        " where NomUsuario = '" + nem + "' order by(NombreRequisito) asc");
                    fila = selecciona.extrae_registro(adaptador, "RequisitosNoCriticos");
                    return fila["NombreRequisito"].ToString();
                }
                catch (Exception)
                {
                    m = "No se encuentra el Requisito";
                    return m;
                }
            }
            else
            {
                m = "Fallo en la base de datos";
                return m;

            }
        }
        public String regresaNom5(string nem)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            string m = "";
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select TOP 5 (NombreRequisito) from RequisitosNoCriticos r inner join Usuario u on r.idUsuario=u.idUsuario" +
                        " where NomUsuario = '" + nem + "' order by(NombreRequisito) asc");
                    fila = selecciona.extrae_registro(adaptador, "RequisitosNoCriticos");
                    return fila["NombreRequisito"].ToString();
                }
                catch (Exception)
                {
                    m = "No se encuentra el Requisito";
                    return m;
                }
            }
            else
            {
                m = "Fallo en la base de datos";
                return m;

            }
        }
    }
}