﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UTP_MEG.MODELO;

namespace UTP_MEG.VISTA
{
    public partial class Requisito4 : System.Web.UI.Page
    {
        RequisitosCriticos rc = new RequisitosCriticos();
        Usuario u = new Usuario();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!System.IO.Directory.Exists(Server.MapPath(@"~/Requisitos/Req4/")))
            {
                System.IO.Directory.CreateDirectory(Server.MapPath(@"~/Requisitos/Req4/"));
            }
        }

        protected void SubirInforme_Click(object sender, EventArgs e)
        {
            rc.idUsuario = u.regresaIDU();
            rc.DireccionRequisito = Finformeau.FileName.ToString();
            rc.NumRequisito = 4;
            rc.Verificacion = "No visto";
            if (Finformeau.HasFile && Path.GetExtension(Finformeau.FileName) == ".pdf" && Finformeau.FileName.ToString() != String.Empty)
            {
                String filePath = Server.MapPath(@"~/Requisitos/Req4/" + Finformeau.FileName);
                if (File.Exists(filePath))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert(' Ya Existe no se guardo :(')", true);
                }
                else
                {
                    Finformeau.SaveAs(filePath);
                    SubirInforme.Visible = false;
                    Finformeau.Enabled = false;
                    rc.altaRequisitosC();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Guardado correctamente ;)'); window.location='/VISTA/Requisito5.aspx';", true);
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('La extension es incorrecta o no se selecciono ningun archivo :$')", true);
            }
        }
    }
}