﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace UTP_MEG.VISTA
{
    public partial class Signup : System.Web.UI.Page
    {
        
             protected void Page_Load(object sender, EventArgs e)
        {
            

            }
            // Add the initial item - you can add this even if the options from the
            // db were not successfully loaded
            //DropDownList1.Items.Insert(0, new ListItem("<Select Subject>", "0"));
            //btnRegistrar.Enabled = false;
        

        
        

        
            
        }

    }

