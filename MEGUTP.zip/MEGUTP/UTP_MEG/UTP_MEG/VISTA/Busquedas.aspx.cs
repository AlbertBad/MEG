﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UTP_MEG.MODELO;

namespace MEG.Views
{
    public partial class Busquedas : System.Web.UI.Page
    {
        Empresa em = new Empresa();
        protected void Page_Load(object sender, EventArgs e)
        {
            em.carga(ddlEmpresa);
        }

        protected void imgbEditar_Click(object sender, ImageClickEventArgs e)
        {
            if (ddlEmpresa.Text.Equals("Seleccionar..."))
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Seleccione una Empresa primero')", true);
            else
            {
                Panel1.Visible = true;
                ddlEmpresa.Enabled = false;

            }
        }

        protected void imgbDelete_Click(object sender, ImageClickEventArgs e)
        {
            if (ddlEmpresa.Text.Equals("Seleccionar..."))
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Seleccione una Empresa primero')", true);
            else
            {
                em.Eliminar(ddlEmpresa.Text);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(),"llave1", "alert('Se elimino la empresa correctamente'); window.location='/VISTA/Busquedas.aspx';", true);               
            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            em.ModificarEmpresa(txtdireccion.Text, txttelefono.Text, ddlEmpresa.Text);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Modificacion con exito !!'); window.location='/VISTA/Busquedas.aspx';", true);
        }
    }
}