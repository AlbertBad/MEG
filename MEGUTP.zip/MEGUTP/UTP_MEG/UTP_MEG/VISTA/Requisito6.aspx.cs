﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using UTP_MEG.MODELO;

namespace UTP_MEG.VISTA
{
    public partial class Requisito6 : System.Web.UI.Page
    {
        RequisitosCriticos rc = new RequisitosCriticos();
        Usuario u = new Usuario();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!System.IO.Directory.Exists(Server.MapPath(@"~/Requisitos/Req6/")))
            {
                System.IO.Directory.CreateDirectory(Server.MapPath(@"~/Requisitos/Req6/"));
            }
        }

        protected void SubirDocdeetica_Click(object sender, EventArgs e)
        {
            rc.idUsuario = u.regresaIDU();
            rc.DireccionRequisito = Fdocetica.FileName.ToString();
            rc.NumRequisito = 6;
            rc.Verificacion = "No visto";
            if (Fdocetica.HasFile && Path.GetExtension(Fdocetica.FileName) == ".pdf" && Fdocetica.FileName.ToString() != String.Empty)
            {
                String filePath = Server.MapPath(@"~/Requisitos/Req6/" + Fdocetica.FileName);
                if (File.Exists(filePath))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert(' Ya Existe no se guardo :(')", true);
                }
                else
                {
                    Fdocetica.SaveAs(filePath);
                    SubirDocdeetica.Visible = false;
                    Fdocetica.Enabled = false;
                    rc.altaRequisitosC();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Guardado correctamente ;)'); window.location='/VISTA/Requisito7.aspx';", true);
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('La extension es incorrecta o no se selecciono ningun archivo :$')", true);
            }
        }
    }
}