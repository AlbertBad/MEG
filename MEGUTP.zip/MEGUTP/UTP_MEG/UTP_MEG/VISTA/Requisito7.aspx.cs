﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UTP_MEG.MODELO;
using System.IO;

namespace UTP_MEG.VISTA
{
    public partial class Requisito7 : System.Web.UI.Page
    {
        RequisitosCriticos rc = new RequisitosCriticos();
        Usuario u = new Usuario();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!System.IO.Directory.Exists(Server.MapPath(@"~/Requisitos/Req7/")))
            {
                System.IO.Directory.CreateDirectory(Server.MapPath(@"~/Requisitos/Req7/"));
            }
        }

        protected void SubirDocprob_Click(object sender, EventArgs e)
        {
            rc.idUsuario = u.regresaIDU();
            rc.DireccionRequisito = Docprob.FileName.ToString();
            rc.NumRequisito = 7;
            rc.Verificacion = "No visto";
            if (Docprob.HasFile && Path.GetExtension(Docprob.FileName) == ".pdf" && Docprob.FileName.ToString() != String.Empty)
            {
                String filePath = Server.MapPath(@"~/Requisitos/Req7/" + Docprob.FileName);
                if (File.Exists(filePath))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert(' Ya Existe no se guardo :(')", true);
                }
                else
                {
                    Docprob.SaveAs(filePath);
                    SubirDocprob.Visible = false;
                    Docprob.Enabled = false;
                    rc.altaRequisitosC();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Guardado correctamente ;)')", true);
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('La extension es incorrecta o no se selecciono ningun archivo :$')", true);
            }
        }

        protected void SubirDoccateg_Click(object sender, EventArgs e)
        {
            rc.idUsuario = u.regresaIDU();
            rc.DireccionRequisito = Lxcateg.FileName.ToString();
            rc.NumRequisito = 7;
            rc.Verificacion = "No visto";
            if (Lxcateg.HasFile && Path.GetExtension(Lxcateg.FileName) == ".pdf" && Lxcateg.FileName.ToString() != String.Empty)
            {
                String filePath = Server.MapPath(@"~/Requisitos/Req7/" + Lxcateg.FileName);
                if (File.Exists(filePath))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert(' Ya Existe no se guardo :(')", true);
                }
                else
                {
                    Lxcateg.SaveAs(filePath);
                    SubirDoccateg.Visible = false;
                    Lxcateg.Enabled = false;
                    rc.altaRequisitosC();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Guardado correctamente ;)'); window.location='/VISTA/Requisito8.aspx';", true);
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('La extension es incorrecta o no se selecciono ningun archivo :$')", true);
            }
        }
    }
}