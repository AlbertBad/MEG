﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using UTP_MEG.MODELO;

namespace UTP_MEG.VISTA
{
    public partial class Requisito14 : System.Web.UI.Page
    {
        RequisitosCriticos rc = new RequisitosCriticos();
        Usuario u = new Usuario();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!System.IO.Directory.Exists(Server.MapPath(@"~/Requisitos/Req14/")))
            {
                System.IO.Directory.CreateDirectory(Server.MapPath(@"~/Requisitos/Req14/"));
            }
        }

        protected void Sdocumento_Click(object sender, EventArgs e)
        {
            rc.idUsuario = u.regresaIDU();
            rc.DireccionRequisito = FUdocumento.FileName.ToString();
            rc.NumRequisito = 14;
            rc.Verificacion = "No visto";
            if (FUdocumento.HasFile && Path.GetExtension(FUdocumento.FileName) == ".pdf" && FUdocumento.FileName.ToString() != String.Empty)
            {
                String filePath = Server.MapPath(@"~/Requisitos/Req14/" + FUdocumento.FileName);
                if (File.Exists(filePath))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert(' Ya Existe no se guardo :(')", true);
                }
                else
                {
                    FUdocumento.SaveAs(filePath);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Guardado correctamente ;)')", true);
                    Sdocumento.Visible = false;
                    FUdocumento.Enabled = false;
                    rc.altaRequisitosC();
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('La extension es incorrecta o no se selecciono ningun archivo :$')", true);
            }
        }

        protected void Sdifusion_Click(object sender, EventArgs e)
        {
            rc.idUsuario = u.regresaIDU();
            rc.DireccionRequisito = FUdifusion.FileName.ToString();
            rc.NumRequisito = 14;
            rc.Verificacion = "No visto";
            if (FUdifusion.HasFile && Path.GetExtension(FUdifusion.FileName) == ".pdf" && FUdifusion.FileName.ToString() != String.Empty)
            {
                String filePath = Server.MapPath(@"~/Requisitos/Req14/" + FUdifusion.FileName);
                if (File.Exists(filePath))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert(' Ya Existe no se guardo :(')", true);
                }
                else
                {
                    FUdifusion.SaveAs(filePath);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Guardado correctamente ;)')", true);
                    Sdifusion.Visible = false;
                    FUdifusion.Enabled = false;
                    rc.altaRequisitosC();
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('La extension es incorrecta o no se selecciono ningun archivo :$')", true);
            }
        }

        protected void Sinformes_Click(object sender, EventArgs e)
        {
            rc.idUsuario = u.regresaIDU();
            rc.DireccionRequisito = FUinformes.FileName.ToString();
            rc.NumRequisito = 14;
            rc.Verificacion = "No visto";
            if (FUinformes.HasFile && Path.GetExtension(FUinformes.FileName) == ".pdf" && FUinformes.FileName.ToString() != String.Empty)
            {
                String filePath = Server.MapPath(@"~/Requisitos/Req14/" + FUinformes.FileName);
                if (File.Exists(filePath))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert(' Ya Existe no se guardo :(')", true);
                }
                else
                {
                    FUinformes.SaveAs(filePath);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Guardado correctamente ;)')", true);
                    Sinformes.Visible = false;
                    FUinformes.Enabled = false;
                    rc.altaRequisitosC();
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('La extension es incorrecta o no se selecciono ningun archivo :$')", true);
            }
        }

        protected void Saplicacion_Click(object sender, EventArgs e)
        {
            rc.idUsuario = u.regresaIDU();
            rc.DireccionRequisito = FUaplicacion.FileName.ToString();
            rc.NumRequisito = 14;
            rc.Verificacion = "No visto";
            if (FUaplicacion.HasFile && Path.GetExtension(FUaplicacion.FileName) == ".pdf" && FUaplicacion.FileName.ToString() != String.Empty)
            {
                String filePath = Server.MapPath(@"~/Requisitos/Req14/" + FUaplicacion.FileName);
                if (File.Exists(filePath))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert(' Ya Existe no se guardo :(')", true);
                }
                else
                {
                    FUaplicacion.SaveAs(filePath);
                    Saplicacion.Visible = false;
                    FUaplicacion.Enabled = false;
                    rc.altaRequisitosC();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Guardado correctamente, ha terminado su auditoria!! ;)'); window.location='/VISTA/Home.aspx';", true);
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('La extension es incorrecta o no se selecciono ningun archivo :$')", true);
            }
        }
    }
}