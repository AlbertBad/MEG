﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UTP_MEG.MODELO;
using System.IO;

namespace UTP_MEG.VISTA
{
    public partial class Requisito5 : System.Web.UI.Page
    {
        RequisitosCriticos rc = new RequisitosCriticos();
        Usuario u = new Usuario();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!System.IO.Directory.Exists(Server.MapPath(@"~/Requisitos/Req5/")))
            {
                System.IO.Directory.CreateDirectory(Server.MapPath(@"~/Requisitos/Req5/"));
            }
        }

        protected void SubirDocdecuetionario_Click(object sender, EventArgs e)
        {
            rc.idUsuario = u.regresaIDU();
            rc.DireccionRequisito = Fcuesstionariocl.FileName.ToString();
            rc.NumRequisito = 5;
            rc.Verificacion = "No visto";
            if (Fcuesstionariocl.HasFile && Path.GetExtension(Fcuesstionariocl.FileName) == ".pdf" && Fcuesstionariocl.FileName.ToString() != String.Empty)
            {
                String filePath = Server.MapPath(@"~/Requisitos/Req5/" + Fcuesstionariocl.FileName);
                if (File.Exists(filePath))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert(' Ya Existe no se guardo :(')", true);
                }
                else
                {
                    Fcuesstionariocl.SaveAs(filePath);
                    SubirDocdecuetionario.Visible = false;
                    Fcuesstionariocl.Enabled = false;
                    rc.altaRequisitosC();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Guardado correctamente ;)'); window.location='/VISTA/Requisito6.aspx';", true);
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('La extension es incorrecta o no se selecciono ningun archivo :$')", true);
            }
        }
    }
}