﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using UTP_MEG.MODELO;

namespace UTP_MEG.VISTA
{
    public partial class Requisito13 : System.Web.UI.Page
    {
        RequisitosCriticos rc = new RequisitosCriticos();
        Usuario u = new Usuario();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!System.IO.Directory.Exists(Server.MapPath(@"~/Requisitos/Req13/")))
            {
                System.IO.Directory.CreateDirectory(Server.MapPath(@"~/Requisitos/Req13/"));
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            rc.idUsuario = u.regresaIDU();
            rc.DireccionRequisito = FileUpload1.FileName.ToString();
            rc.NumRequisito = 13;
            rc.Verificacion = "No visto";
            if (FileUpload1.HasFile && Path.GetExtension(FileUpload1.FileName) == ".pdf" && FileUpload1.FileName.ToString() != String.Empty)
            {
                String filePath = Server.MapPath(@"~/Requisitos/Req13/" + FileUpload1.FileName);
                if (File.Exists(filePath))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert(' Ya Existe no se guardo :(')", true);
                }
                else
                {
                    FileUpload1.SaveAs(filePath);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Guardado correctamente ;)')", true);
                    Button1.Visible = false;
                    FileUpload1.Enabled = false;
                    rc.altaRequisitosC();
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('La extension es incorrecta o no se selecciono ningun archivo :$')", true);
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            rc.idUsuario = u.regresaIDU();
            rc.DireccionRequisito = FileUpload2.FileName.ToString();
            rc.NumRequisito = 13;
            rc.Verificacion = "No visto";
            if (FileUpload2.HasFile && Path.GetExtension(FileUpload2.FileName) == ".pdf" && FileUpload2.FileName.ToString() != String.Empty)
            {
                String filePath = Server.MapPath(@"~/Requisitos/Req13/" + FileUpload2.FileName);
                if (File.Exists(filePath))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert(' Ya Existe no se guardo :(')", true);
                }
                else
                {
                    FileUpload2.SaveAs(filePath);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Guardado correctamente ;)')", true);
                    Button2.Visible = false;
                    FileUpload2.Enabled = false;
                    rc.altaRequisitosC();
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('La extension es incorrecta o no se selecciono ningun archivo :$')", true);
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            rc.idUsuario = u.regresaIDU();
            rc.DireccionRequisito = FileUpload3.FileName.ToString();
            rc.NumRequisito = 13;
            rc.Verificacion = "No visto";
            if (FileUpload3.HasFile && Path.GetExtension(FileUpload3.FileName) == ".pdf" && FileUpload3.FileName.ToString() != String.Empty)
            {
                String filePath = Server.MapPath(@"~/Requisitos/Req13/" + FileUpload3.FileName);
                if (File.Exists(filePath))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert(' Ya Existe no se guardo :(')", true);
                }
                else
                {
                    FileUpload3.SaveAs(filePath);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Guardado correctamente ;)')", true);
                    Button3.Visible = false;
                    FileUpload3.Enabled = false;
                    rc.altaRequisitosC();
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('La extension es incorrecta o no se selecciono ningun archivo :$')", true);
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            rc.idUsuario = u.regresaIDU();
            rc.DireccionRequisito = FileUpload4.FileName.ToString();
            rc.NumRequisito = 13;
            rc.Verificacion = "No visto";
            if (FileUpload4.HasFile && Path.GetExtension(FileUpload4.FileName) == ".pdf" && FileUpload4.FileName.ToString() != String.Empty)
            {
                String filePath = Server.MapPath(@"~/Requisitos/Req13/" + FileUpload4.FileName);
                if (File.Exists(filePath))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert(' Ya Existe no se guardo :(')", true);
                }
                else
                {
                    FileUpload4.SaveAs(filePath);
                    Button4.Visible = false;
                    FileUpload4.Enabled = false;
                    rc.altaRequisitosC();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('Guardado correctamente ;)'); window.location='/VISTA/Requisito14.aspx';", true);
                }
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "Name of the field", "alert('La extension es incorrecta o no se selecciono ningun archivo :$')", true);
            }
        }
    }
}